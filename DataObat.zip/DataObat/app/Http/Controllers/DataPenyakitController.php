<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DataPenyakitController extends Controller
{
    //
}
